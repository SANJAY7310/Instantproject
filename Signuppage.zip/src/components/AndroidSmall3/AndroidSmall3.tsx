import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import classes from './AndroidSmall3.module.css';
import { UnionIcon } from './UnionIcon.js';

interface Props {
  className?: string;
}
/* @figmaId 77:5 */
export const AndroidSmall3: FC<Props> = memo(function AndroidSmall3(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.union}>
        <UnionIcon className={classes.icon} />
      </div>
      <div className={classes.createAccount}>Create Account :)</div>
      <div className={classes.enterEmailId}>Enter Email Id</div>
      <div className={classes.createUsername}>Create Username</div>
      <div className={classes.createPassward}>Create Passward</div>
      <div className={classes.line1}></div>
      <div className={classes.line2}></div>
      <div className={classes.line3}></div>
      <div className={classes.goBack}></div>
      <div className={classes.rectangle3}></div>
      <div className={classes.sIGNUP}>SIGN UP</div>
    </div>
  );
});
