import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import classes from './AndroidSmall1.module.css';
import { UnionIcon } from './UnionIcon.js';

interface Props {
  className?: string;
}
/* @figmaId 76:3 */
export const AndroidSmall1: FC<Props> = memo(function AndroidSmall1(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.union}>
        <UnionIcon className={classes.icon} />
      </div>
      <div className={classes.letSGetStarted}>
        <div className={classes.textBlock}>Let’s Get</div>
        <div className={classes.textBlock2}>Started</div>
      </div>
      <div className={classes.downloadYourProjectNow}>
        <div className={classes.textBlock3}>Download your </div>
        <div className={classes.textBlock4}>project Now</div>
      </div>
      <div className={classes.rectangle1}></div>
      <div className={classes.jOINNOW}>JOIN NOW</div>
    </div>
  );
});
