import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import classes from './AndroidSmall2.module.css';

interface Props {
  className?: string;
}
/* @figmaId 17:39 */
export const AndroidSmall2: FC<Props> = memo(function AndroidSmall2(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.cashAndCreditCard}></div>
      <div className={classes.microsoftProject}></div>
      <div className={classes.home}></div>
      <div className={classes.downloadsFolder}></div>
      <div className={classes.rectangle3}></div>
      <div className={classes.lANGUAGES}>LANGUAGES</div>
      <div className={classes.back}></div>
      <div className={classes.pYTHON}>PYTHON</div>
      <div className={classes.back2}></div>
      <div className={classes.back3}></div>
      <div className={classes.jAVA}>JAVA</div>
      <div className={classes.c}>C++</div>
      <div className={classes.back4}></div>
      <div className={classes.hTML}>HTML</div>
      <div className={classes.back5}></div>
      <div className={classes.jAVASCRIPT}>
        <div className={classes.textBlock}>JAVA </div>
        <div className={classes.textBlock2}>SCRIPT</div>
      </div>
      <div className={classes.back6}></div>
      <div className={classes.home2}></div>
    </div>
  );
});
