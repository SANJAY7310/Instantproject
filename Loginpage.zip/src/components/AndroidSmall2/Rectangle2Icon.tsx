import { memo, SVGProps } from 'react';

const Rectangle2Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 157 60' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M0 30C0 13.4315 13.4315 0 30 0H127C143.569 0 157 13.4315 157 30V30C157 46.5685 143.569 60 127 60H30C13.4315 60 0 46.5685 0 30V30Z'
      fill='black'
    />
  </svg>
);

const Memo = memo(Rectangle2Icon);
export { Memo as Rectangle2Icon };
