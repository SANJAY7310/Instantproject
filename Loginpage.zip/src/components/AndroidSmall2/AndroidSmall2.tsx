import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import classes from './AndroidSmall2.module.css';
import { Rectangle2Icon } from './Rectangle2Icon.js';
import { UnionIcon } from './UnionIcon.js';

interface Props {
  className?: string;
}
/* @figmaId 77:4 */
export const AndroidSmall2: FC<Props> = memo(function AndroidSmall2(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.union}>
        <UnionIcon className={classes.icon} />
      </div>
      <div className={classes.welcomeBack}>Welcome Back!</div>
      <div className={classes.enterYourUsernamePassword}>Enter Your Username &amp; Password</div>
      <div className={classes.username}>Username</div>
      <div className={classes.password}>Password</div>
      <div className={classes.line4}></div>
      <div className={classes.line5}></div>
      <div className={classes.image1}></div>
      <div className={classes.rectangle2}>
        <Rectangle2Icon className={classes.icon2} />
      </div>
      <div className={classes.lOGIN}>LOGIN</div>
    </div>
  );
});
